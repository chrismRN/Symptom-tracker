# RespiTrack — Install on Your iPhone

## Step 1: Host it (one-time, ~5 minutes, free)

**GitHub Pages (recommended):**
1. Go to github.com → click **+** → **New repository**
2. Name it `respitrack`, set it to **Public** (or Private with Pages enabled on a paid plan), click **Create repository**
3. Click **uploading an existing file** and drag in ALL files from this folder:
   - index.html
   - manifest.json
   - sw.js
   - icon-180.png, icon-192.png, icon-512.png
4. Click **Commit changes**
5. Go to **Settings → Pages** → under "Branch" select **main** → **Save**
6. Wait ~1 minute. Your app is live at:
   `https://YOUR-USERNAME.github.io/respitrack/`

Note: a public repo means the app code is visible online — but your health data is NOT.
All entries stay in your phone's local storage and never leave your device.

## Step 2: Install on your iPhone

1. Open the URL above in **Safari** (must be Safari, not Chrome)
2. Tap the **Share** button (square with arrow)
3. Scroll down, tap **Add to Home Screen**
4. Tap **Add**

Done. The RespiTrack icon appears on your home screen, opens full-screen
like a native app, and works offline.

## Important notes

- **Data lives on your phone.** It survives closing the app and restarting your phone.
  It is deleted only if you clear Safari website data or delete the app icon AND site data.
- **Back up before appointments:** My Meds tab → "Export backup (JSON)" saves a file
  you can store in iCloud/Files.
- **Doctor visit:** Summary tab → set date range → "Print / Save PDF" → AirPrint or
  save as PDF to share via MyChart/email.
